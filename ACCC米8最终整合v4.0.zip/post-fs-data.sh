#!/system/bin/sh
# 请不要硬编码/magisk/modname/...;相反，请使用$MODDIR/...
# 这将使您的脚本兼容，即使Magisk以后改变挂载点
MODDIR=${0%/*}

# 此脚本将在post-fs-data模式下执行

#禁止mi-rcs写入日志
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService

#冻结应用
pm disable com.android.stk
pm disable com.xiaomi.simactivate.service
pm disable com.miui.analytics
pm disable com.miui.systemAdSolution
pm disable com.xiaomi.payment
pm disable com.xiaomi.miplay_client
pm disable com.miui.yellowpage
pm disable com.miui.touchassistant
pm disable com.miui.bugreport
pm disable com.milink.service
pm disable com.bsp.catchlog
pm disable com.android.traceur
pm disable com.android.printspooler
pm disable com.android.emergency
pm disable com.android.bips
pm disable com.xiaomi.aiasst.service
pm disable com.xiaomi.market
pm disable com.xiaomi.xmsf
pm disable com.miui.player
pm disable com.miui.personalassistant
pm disable com.miui.miservice
pm disable com.miui.hybrid.accessory
pm disable com.miui.hybrid
pm disable com.miui.contentextension
pm disable com.miui.aod
pm disable com.mipay.wallet
pm disable com.android.updater
pm disable com.android.soundrecorder
pm disable com.android.quicksearchbox
pm disable com.mfashiongallery.emag
pm disable com.miui.voiceassist
pm disable com.miui.mishare.connectivity
pm disable com.miui.voicetrigger
pm disable com.xiaomi.mibrain.speech
pm disable com.xiaomi.pass
pm disable com.xiaomi.shop
pm disable com.xiaomi.vipaccount
pm disable com.miui.accessibility
pm disable com.xiaomi.youpin
pm disable com.miui.newmidrive
pm disable com.miui.nextpay
pm disable com.miui.tsmclient
pm disable com.miui.smarttravel

#删除无用垃圾
rm -rf /data/vendor/thermal/config
rm -rf /data/vendor/thermal/thermal.dump
rm -rf /data/vendor/thermal/thermal_history.dump
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
rm -rf /storage/emulated/0/.com.android.providers.downloads
rm -rf /storage/emulated/0/.com.android.providers.downloads.ui
rm -rf /data/user_de/0/org.meowcat.edxposed.manager/log/
rm -rf /data/user/0/com.douban.frodo/app_rexxar-douban
rm -rf /data/user/0/com.douban.frodo/cache
rm -rf /data/vendor/wlan_logs
rm -rf /data/user/0/com.picsart.studio/files/bitmap_cache/editor/view
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService

#禁用I/O调试
echo 0 > /sys/block/dm-0/queue/iostats
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats
echo 0 > /sys/block/mmcblk1/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
#关闭magisk edxposed miui 内测日志
if
rm -rf /cache/magisk.log
touch   /cache/magisk.log
chmod 000  /cache/magisk.log
busybox chattr +i  /cache/magisk.log

rm -rf  /data/user_de/0/com.solohsu.android.edxp.manager/log
touch    /data/user_de/0/com.solohsu.android.edxp.manager/log
chmod 000   /data/user_de/0/com.solohsu.android.edxp.manager/log
busybox chattr +i   /data/user_de/0/com.solohsu.android.edxp.manager/log

rm -rf /data/user_de/0/org.meowcat.edxposed.manager/log
touch   /data/user_de/0/org.meowcat.edxposed.manager/log
chmod 000  /data/user_de/0/org.meowcat.edxposed.manager/log
busybox chattr +i  /data/user_de/0/org.meowcat.edxposed.manager/log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 


then
echo "清理成功"
fi