#!/system/bin/sh


(
  killall audioserver 2>/dev/null
)&
