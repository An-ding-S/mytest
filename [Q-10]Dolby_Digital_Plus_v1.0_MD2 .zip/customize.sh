SKIPUNZIP=1

# Dolby Digital Plus® operations

unzip "$ZIPFILE" module.prop -d $MODPATH >&2
unzip -o "$ZIPFILE" 'META-INF/*' -d $TMPDIR >&2

source $TMPDIR/META-INF/functions

go
