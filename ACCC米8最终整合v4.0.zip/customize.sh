SKIPMOUNT=false

PROPFILE=true

POSTFSDATA=true

LATESTARTSERVICE=true


##########################################################################################
# Installation Message
##########################################################################################
  ui_print "*******************************"
  ui_print "       	Magisk Module:         "
  ui_print "     For ACCC    By 修仙猫    "
  ui_print "*******************************"
#添加您要精简的APP/文件夹目录
echo "注意！！！"
echo "此版本版为第一版，也可能是最后一版。进群895152818一起搞机吧！"
ui_print "


description=
1.杀后台优化使得后台挂的更牢固
2.默认关闭定位（省去不必要的耗电）
3.关闭hw叠加层
4.降低wifi扫描时间（省电）
5.开启优化SurfaceFlinger缓冲区
6.关闭log
7.sqlite提速
8.开启SDCardFS（加快读写速度）
9.三十五阶音量调节
10.手机待机时更省电
11.禁止写入日志
12.冻结无用应用
13.删除无用垃圾
14.禁用I/O调试
15.全局iOS过渡动画
16.增加AD去广告
17.增加iOS锁屏充电音效
18.使后台更牢固
19.系统级应用机制管理内存优化
20.开启待机深度睡眠
21.录音质量优化
22.GPS优化
功能性开关:
1.开启memc动态补偿 
2.扬声器清理 
3.数据WiFi双加速(部分机型失效)
4.增加视频工具箱-音效-影音功能
5.听感调节
6.开启快充(部分机型有用，建议刷其他模块开启，不和其他模块冲突。)
7.微信视频美颜
8.开启游戏变声器(部分机型有效)
……………………
"
##########################################################################################
# Permissions
##########################################################################################
#释放文件，普通shell命令
on_install() {
  ui_print "- 正在释放文件"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}
#高通wifi增强，来自wifi bonding
[ -x "$(which magisk)" ] && MIRRORPATH=$(magisk --path)/.magisk/mirror || unset MIRRORPATH
array=$(find /system /vendor -name WCNSS_qcom_cfg.ini)
for CFG in $array
do
[[ -f $CFG ]] && [[ ! -L $CFG ]] && {
SELECTPATH=$CFG
mkdir -p `dirname $MODPATH$CFG`
cp -af $MIRRORPATH$SELECTPATH $MODPATH$SELECTPATH
sed -i '/gChannelBondingMode24GHz=/d;/gChannelBondingMode5GHz=/d;/gForce1x1Exception=/d;s/^END$/gChannelBondingMode24GHz=1\ngChannelBondingMode5GHz=1\ngForce1x1Exception=0\nEND/g' $MODPATH$SELECTPATH
}
done
[[ -z $SELECTPATH ]] && abort "- Installation FAILED. Your device didn't support WCNSS_qcom_cfg.ini." || { mkdir -p $MODPATH/system; mv -f $MODPATH/vendor $MODPATH/system/vendor;}

set_permissions() {

  set_perm_recursive  $MODPATH  0  0  0755  0644
  set_perm  $MODPATH/system/bin/logd       0       0       0550
  
}

##########################################################################################
# Custom Functions
##########################################################################################
#!system/bin/sh

#冻结应用
pm disable com.android.stk
pm disable com.xiaomi.simactivate.service
pm disable com.miui.analytics
pm disable com.miui.systemAdSolution
pm disable com.xiaomi.payment
pm disable com.xiaomi.miplay_client
pm disable com.miui.yellowpage
pm disable com.miui.touchassistant
pm disable com.miui.bugreport
pm disable com.milink.service
pm disable com.bsp.catchlog
pm disable com.android.traceur
pm disable com.android.printspooler
pm disable com.android.emergency
pm disable com.android.bips
pm disable com.xiaomi.aiasst.service
pm disable com.xiaomi.market
pm disable com.xiaomi.xmsf
pm disable com.miui.player
pm disable com.miui.personalassistant
pm disable com.miui.miservice
pm disable com.miui.hybrid.accessory
pm disable com.miui.hybrid
pm disable com.miui.contentextension
pm disable com.miui.aod
pm disable com.mipay.wallet
pm disable com.android.updater
pm disable com.android.soundrecorder
pm disable com.android.quicksearchbox
pm disable com.mfashiongallery.emag

#删除无用垃圾
rm -rf /data/vendor/thermal/config
rm -rf /data/vendor/thermal/thermal.dump
rm -rf /data/vendor/thermal/thermal_history.dump
rm -rf /data/user_de/0/com.miui.home/cache/debug_log
rm -rf /storage/emulated/0/.com.android.providers.downloads
rm -rf /storage/emulated/0/.com.android.providers.downloads.ui
rm -rf /data/user_de/0/org.meowcat.edxposed.manager/log/
rm -rf /data/user/0/com.douban.frodo/app_rexxar-douban
rm -rf /data/user/0/com.douban.frodo/cache
rm -rf /data/vendor/wlan_logs
rm -rf /data/user/0/com.picsart.studio/files/bitmap_cache/editor/view
rm -rf /data/media/0/JuphoonService
touch /data/media/0/JuphoonService
chmod 000 /data/media/0/JuphoonService

#禁用I/O调试
echo 0 > /sys/block/dm-0/queue/iostats
echo 0 > /sys/block/mmcblk0/queue/iostats
echo 0 > /sys/block/mmcblk0rpmb/queue/iostats
echo 0 > /sys/block/mmcblk1/queue/iostats
echo 0 > /sys/block/sda/queue/iostats
#关闭magisk edxposed miui 内测日志
if
rm -rf /cache/magisk.log
touch   /cache/magisk.log
chmod 000  /cache/magisk.log
/sbin/.magisk/busybox/chattr +i  /cache/magisk.log

rm -rf  /data/user_de/0/com.solohsu.android.edxp.manager/log
touch    /data/user_de/0/com.solohsu.android.edxp.manager/log
chmod 000   /data/user_de/0/com.solohsu.android.edxp.manager/log
/sbin/.magisk/busybox/chattr +i   /data/user_de/0/com.solohsu.android.edxp.manager/log

rm -rf /data/user_de/0/org.meowcat.edxposed.manager/log
touch   /data/user_de/0/org.meowcat.edxposed.manager/log
chmod 000  /data/user_de/0/org.meowcat.edxposed.manager/log
/sbin/.magisk/busybox/chattr +i  /data/user_de/0/org.meowcat.edxposed.manager/log

rm -rf /data/user_de/0/com.miui.home/cache/debug_log
touch   /data/user_de/0/com.miui.home/cache/debug_log
chmod 000  /data/user_de/0/com.miui.home/cache/debug_log 

PROPFILE=true
SKIPUNZIP=1
unzip -qqo "$ZIPFILE" 'common/*' -d $TMPDIR >&2
unzip -qjo "$ZIPFILE" 'common/functions.sh' -d $TMPDIR >&2
. $TMPDIR/functions.sh

SKIPUNZIP=1

##########################################################################################
# 替换列表
##########################################################################################

# 列出你想在系统中直接替换的所有目录
# 查看文档，了解更多关于Magic Mount如何工作的信息，以及你为什么需要它


# 按照以下格式构建列表
# 这是一个示例
REPLACE_EXAMPLE="
/system/app/Youtube
/system/priv-app/SystemUI
/system/priv-app/Settings
/system/framework
"

# 在这里建立您自己的清单
REPLACE="
"
##########################################################################################
# 安装设置
##########################################################################################
 
# 将 $ZIPFILE 提取到 $MODPATH
ui_print "- 解压模块文件"
unzip -o "$ZIPFILE" -x 'META-INF/*' -d $MODPATH >&2

work_dir=/sdcard/ADhosts
syshosts=/system/etc/hosts

if [ ! -d $work_dir ];then
   mkdir -p $work_dir
fi
if [ ! -e $work_dir/update.log ];then
   touch $work_dir/update.log
   echo "paceholder" >> $work_dir/update.log
   sed -i "G;G;G;G;G" $work_dir/update.log
   sed -i '1d' $work_dir/update.log
fi
if [ ! -e $work_dir/Start.sh ];then
   touch $work_dir/Start.sh
   echo "# 手动更新，请使用root权限执行" >> $work_dir/Start.sh
   echo "sh /data/adb/modules/AD-Hosts/service.sh" >> $work_dir/Start.sh
fi

tar -xf $MODPATH/tools.tar.xz -C $TMPDIR >&2
chmod -R 0755 $TMPDIR/tools
alias keycheck="$TMPDIR/tools/$ARCH32/keycheck"

keytest() {
  ui_print "- 音量键测试"
  ui_print "   请按任意音量键:"
  if (timeout 3 /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events); then
    return 0
  else
    ui_print "   再试一次:"
    timeout 3 keycheck
    local SEL=$?
    [ $SEL -eq 143 ] && abort "   未检测到音量键!" || return 1
  fi
}

chooseport() {
  # Original idea by chainfire @xda-developers, improved on by ianmacd @xda-developers
  #note from chainfire @xda-developers: getevent behaves weird when piped, and busybox grep likes that even less than toolbox/toybox grep
  while true; do
    /system/bin/getevent -lc 1 2>&1 | /system/bin/grep VOLUME | /system/bin/grep " DOWN" > $TMPDIR/events
    if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUME >/dev/null`); then
      break
    fi
  done
  if (`cat $TMPDIR/events 2>/dev/null | /system/bin/grep VOLUMEUP >/dev/null`); then
    return 0
  else
    return 1
  fi
}

chooseportold() {
  # Keycheck binary by someone755 @Github, idea for code below by Zappo @xda-developers
  # Calling it first time detects previous input. Calling it second time will do what we want
  while true; do
    keycheck
    keycheck
    local SEL=$?
    if [ "$1" == "UP" ]; then
      UP=$SEL
      break
    elif [ "$1" == "DOWN" ]; then
      DOWN=$SEL
      break
    elif [ $SEL -eq $UP ]; then
      return 0
    elif [ $SEL -eq $DOWN ]; then
      return 1
    fi
  done
}

# Have user option to skip vol keys
OIFS=$IFS; IFS=\|; MID=false; NEW=false
case $(echo $(basename $ZIPFILE) | tr '[:upper:]' '[:lower:]') in
  *novk*) ui_print "- 跳过音量键 -";;
  *) if keytest; then
       VKSEL=chooseport
     else
       VKSEL=chooseportold
       ui_print "  ! 检测到遗留设备! 使用旧的 keycheck 方案"
       ui_print " "
       ui_print "- 音量键录入 -"
       ui_print "  请按音量+键:"
       $VKSEL "UP"
       ui_print "  请按音量–键"
       $VKSEL "DOWN"
     fi;;
esac
IFS=$OIFS


ui_print "选择自动更新的地址"
ui_print "  音量+ = GitHub链接(国外推荐)"
ui_print "  音量– = Coding镜像链接(国内推荐)"
if $VKSEL; then
  ui_print "已选择GitHub链接"
  sed -i "s/<hosts>/true/g" $MODPATH/select.txt
else
  ui_print "已选择Coding镜像链接"
  sed -i "s/<hosts>/false/g" $MODPATH/select.txt
fi

ui_print "选择hosts安装模式"
ui_print "  音量+ = systemless"
ui_print "  音量– = system"
if $VKSEL; then
  ui_print "已选择systemless模式"
  sed -i "s/<mod>/true/g" $MODPATH/select.txt
else
  ui_print "已选择system模式"
  ui_print "备份系统hosts文件至$work_dir/hosts.bak"
  sed -i "s/<mod>/false/g" $MODPATH/select.txt
  if [ ! -e $work_dir/syshosts.bak ]; then
     cp $syshosts $work_dir/syshosts.bak
  fi
  mount -o remount,rw /
  mv -f $MODPATH/system/etc/hosts $syshosts
  mount -o remount,ro /
  rm -rf $MODPATH/system
fi

var_miui="`grep_prop ro.miui.ui.version.*`"
if [ $var_miui ]; then
  ui_print " "
  ui_print "是否加入api.ad.xiaomi.com"
  ui_print "加入会教导致小米应用商城里的积分商城与红包功能无法使用"
  ui_print "但会屏蔽掉更多的来自小米的广告"
  ui_print "  音量+ = 加入"
  ui_print "  音量– = 不加入"
  if $VKSEL; then
    ui_print "已选择加入"
    ui_print "正在写入中....."
    sed -i "s/<adxiaomi>/api.ad.xiaomi.com/g" $MODPATH/system/etc/hosts
    sed -i "s/<xiaomi>/true/g" $MODPATH/select.txt
  else
    ui_print "已选择不加入"
  fi
else
  sed -i "s/<adxiaomi>/api.ad.xiaomi.com/g" $MODPATH/system/etc/hosts
  sed -i "s/<xiaomi>/true/g" $MODPATH/select.txt
fi
  ui_print " "
  ui_print "是否加入去除腾讯QQ微信小程序广告"
  ui_print "加入会导致小程序无法看广告得奖励"
  ui_print "  音量+ = 加入"
  ui_print "  音量– = 不加入"
if $VKSEL; then
  ui_print "已选择加入"
  ui_print "正在写入中....."
  sed -i "s/<Tencentgamead1>/adsmind.gdtimg.com/g" $MODPATH/system/etc/hosts
  sed -i "s/<Tencentgamead2>/pgdt.gtimg.cn/g" $MODPATH/system/etc/hosts
  sed -i "s/<QQ>/true/g" $MODPATH/select.txt
else
  ui_print "已选择不加入"
fi

# 删除多余文件
 rm -rf \
 $MODPATH/system/placeholder $MODPATH/customize.sh \
 $MODPATH/*.md $MODPATH/.git* $MODPATH/LICENSE $MODPATH/tools.tar.xz 4>/dev/null

##########################################################################################
# 权限设置
##########################################################################################

  #如果添加到此功能，请将其删除

  # 请注意，magisk模块目录中的所有文件/文件夹都有$MODPATH前缀-在所有文件/文件夹中保留此前缀
  # 一些例子:
  
  # 对于目录(包括文件):
  # set_perm_recursive  <目录>                <所有者> <用户组> <目录权限> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  
  # set_perm_recursive $MODPATH/system/lib 0 0 0755 0644
  # set_perm_recursive $MODPATH/system/vendor/lib/soundfx 0 0 0755 0644

  # 对于文件(不包括文件所在目录)
  # set_perm  <文件名>                         <所有者> <用户组> <文件权限> <上下文> (默认值是: u:object_r:system_file:s0)
  
  # set_perm $MODPATH/system/lib/libart.so 0 0 0644
  # set_perm /data/local/tmp/file.txt 0 0 644

  # 默认权限请勿删除
  set_perm_recursive $MODPATH 0 0 0755 0644
  set_perm $MODPATH/service.sh 0 0 777


print_modname() {
  ui_print "*******************************"
  ui_print "       GPS Pro   "
  ui_print "    OLX-新的&分歧     "
  ui_print "*******************************"
}

# Copy/extract your module files into $MODPATH in on_install.

on_install() {
  # The following is the default implementation: extract $ZIPFILE/system to $MODPATH
  # Extend/change the logic to whatever you want
  ui_print "- Extracting module files"
  unzip -o "$ZIPFILE" 'system/*' -d $MODPATH >&2
}

# Only some special files require specific permissions
# This function will be called after on_install is done
# The default permissions should be good enough for most cases

set_permissions() {
  # The following is the default rule, DO NOT remove
  set_perm_recursive $MODPATH 0 0 0755 0644

  # Here are some examples:
  # set_perm_recursive  $MODPATH/system/lib       0     0       0755      0644
  # set_perm  $MODPATH/system/bin/app_process32   0     2000    0755      u:object_r:zygote_exec:s0
  # set_perm  $MODPATH/system/bin/dex2oat         0     2000    0755      u:object_r:dex2oat_exec:s0
  # set_perm  $MODPATH/system/lib/libart.so       0     0       0644
}

then
echo "清理日志成功"
fi

echo"模块的id ACCC"